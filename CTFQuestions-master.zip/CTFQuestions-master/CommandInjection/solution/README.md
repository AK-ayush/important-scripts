Steps
-----

1. Upload x.php file after changing the `Content-Type: image/png` header in the POST request.
2. Browse to http://0.0.0.0:80/images/x.php?a=cat%20cat-on-the-edge.png

OR

Download image at http://0.0.0.0:80/images/cat-on-the-edge.png and run `strings` on the file.
