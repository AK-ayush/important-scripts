LFI and command injection - Easy
================================

Question - Follow Web Security Practices
----------------------------------------

This application has a flaw. Can you exploit it to get the flag?

[URL](http://0.0.0.0:80)

Hint: Try to create a command injection exploit

Steps
-----

1. Build the docker image using `docker build -t web-sec-practices .`
2. Run the docker container using `docker run --rm --name <container_name> --expose 80 -d web-sec-practices`

Notes
-----

1. Parent apache2 service process is started by root which does not handle requests. It spawns child processes and drops privileges to user www-data for handling requests.
2. The application has LFI and command injection flaws.
3. apache2 service is run in the foreground. Hence access logs sent to stdout and error logs sent to stderr can be viewed in the docker container logs.
4. The server does not allow directory browsing.
5. All file permissions for user www-data to read, write or execute have been removed, except for those in the web root and related to the user's configuration on the server. The user is also allowed to run only shell builtin, ls and cat commands.
    - `kill` command is a shell builtin; if the www-data user kills its own apache2 process, it has been observed that the root apache2 process restarts it.
    - `set` builtin with no arguments lists the values of all shell variables.
    - Using `ls`, the www-data user can view a list of files in some of the directories on the system like /proc, /sys and /dev.
7. A cron job is set to automatically delete files uploaded by users in the /var/www/html/images directory which are older than 10 minutes.
