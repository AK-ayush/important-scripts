<?php
$target_path = "images/";
$target_path = $target_path . basename($_FILES['uploadedfile']['name']);

$err_msg = "There was an error uploading the file. Please upload PNG files of size less than 10KB.";

error_log(print_r($_FILES['uploadedfile'], true));
if($_FILES['uploadedfile']['type'] != 'image/png') {
	error_log('wrong file type');
	echo $err_msg;
} else {
	if (move_uploaded_file($_FILES['uploadedfile']['tmp_name'], $target_path)) {
		echo "The file has been uploaded <a href='" . $target_path . "'>here</a>.";
	} else {
		error_log('could not upload');
		echo $err_msg;
	}
}
?>
