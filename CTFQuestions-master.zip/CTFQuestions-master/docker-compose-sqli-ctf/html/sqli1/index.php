<?php
    session_start();
    $db = new PDO('mysql:host=mysql;dbname=web_1','web_1','somerandompassword');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    try {
        $query = 'SELECT * FROM users WHERE username = "'.$_POST["username"].'"';
        $stmt = $db->query($query);
        $count = $stmt->rowCount();
        if($count > 0) {
            echo "<script>alert('User Found')</script>";
        } else {
            echo "<script>alert('User Not Found')</script>";
        }
    }
    catch (Exception $e) {
        echo "<script>alert('Error in query.')</script>";
    }
?>

<!DOCTYPE html>
<html>
<head>
  <!--Import Google Icon Font-->
  <link href="static/icon.css" rel="stylesheet">
  <!--Import materialize.css-->
  <link type="text/css" rel="stylesheet" href="static/materialize.min.css"  media="screen,projection"/>

  <!--Let browser know website is optimized for mobile-->
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
</head>

<body>
<nav>
  <div class="nav-wrapper">
    <a href="#" class="brand-logo">Walmart User Portal</a>
    <ul id="nav-mobile" class="right hide-on-med-and-down">
    </ul>
  </div>
</nav>

<div class="row">
  <div class="col s12 m12">
    <div class="card-panel" style="margin-top:5em; height: 20em; ">
        <div class="row">
          <div class="col s4" style="padding:2em;">
            This portal is to check if the username exists.
          </div>
          <form class="col s8", action='/index.php', method='POST'>
            <div class="row">
              <div class="input-field col s6">
                <input type="text" id="username" name="username" required>
                <label for="username">Username</label>
              </div>
              <div class="input-field col s6">
                <button class="btn waves-effect waves-light", type="submit", name="submit">
                  Submit
                  <i class="material-icons right">send</i>
                </button>
              </div>
            </div>
        </form>
      </div>
    </div>
  </div>
</div>


<!--Import jQuery before materialize.js-->
<script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
<script type="text/javascript" src="static/materialize.min.js"></script>

</body>
</html>
