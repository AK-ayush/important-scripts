<?php
  session_start();
      $secret = "SjhpM2FuT04wQzFWMWIwUGEw"; #decoded:J8i3anON0C1V1b0Pa0
      if (array_key_exists("user", $_COOKIE) && $_COOKIE["user"] === "admin") {
          if (array_key_exists("HTTP_REFERER", $_SERVER) && strstr($_SERVER["HTTP_REFERER"], "facebook.com")) {
              if (array_key_exists("HTTP_USER_AGENT", $_SERVER) && strstr($_SERVER["HTTP_USER_AGENT"], "InfoSec")) {
                  $flag = base64_decode($secret);
                  header("X-HTTP-Flag: flag{". $flag . "}");
                  echo "Congratulations !! The flag has been sent to you.";
              }
              else {
                  echo "Admin uses only 'InfoSec' browser.";
              }
          }
          else {
              echo "Walmart Admin loves to use facebook. He always comes from facebook.com";
          }
      }
      else {
          setcookie("user", " ");
          echo "Only admin is allowed to visit this portal. Go back child !!";
      }
?>
