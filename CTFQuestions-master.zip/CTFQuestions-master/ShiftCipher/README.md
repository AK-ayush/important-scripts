Encryption and Encoding - Easy Peasy
====================================

Question - War Zone
-------------------

A spy intercepted the following message during the Great Roman War. Can you help us decode it?

ITuyVRqlMJIeplOuozDtHz9gLJ5mVTkiqzIxVTAlrKO0o2qlLKObrF4tFaIfnKImVBXPeTIup2SlYPO0nTHtMzSgo3ImVZXho21uovOyoKOypz9lYPOcplOmLJyxVUEiVTuuqzHtqKAyMPOmqJWmqTy0qKEco24tL2yjnTIlplO0olOSozAlrKO0VTucplOwo21gqJ5cL2S0nJ9hplOxqKWcozptq2SlYvOHnTHtj4qyLKAupvOwnKObMKVtM2I0plOcqUZtozSgMFOzpz9gVUEbnKZtMzSgo3ImVUW1oTIlYvOXqJkcqKZtjdyyLKAupvO1p2HtDJkjnTSvMIEmVUqcqTttLFOmnTyzqPOiMvNmVUEiVTIhL3W5pUDtnTymVT1yp3AuM2ImYvOVnKZtM3WyLKDtozIjnTI3VTShMPOmqJAwMKAmo3VfVRO1M3ImqUImYPO1p2IxVTRtpzyanUDtp2ucMaDto2LtZFO0olOyozAlrKO0VTucplOgMKAmLJqypl4tITuyVTAcpTuypvO1p2IxVTW5VBXVuaIaqKA0qKZtMTyxVT5iqPOKpzSjVRSlo3IhMPO0olO0nTHtLzIanJ5hnJ5aVT9zVUEbMFOuoUObLJWyqP4tFJLtrJ91VTAiqJkxVTEyL3W5pUDtqTucplOgMKAmLJqyYPO5o3Hto2W2nJ91p2k5VTgho3pfVUEbLKDtqTuyVTAcpTuypvO1p2IxVUEiVTIhL3W5pUDtnKDtqKAyMPOuVSWiqQRmVTSfM29lnKEboFjtLFO2LKWcLJ50VT9zVUEbMFQPbzIup2SlVTAcpTuypvO3nKEbVSAbnJM0VQRmYtcQo25mqUW1L3DtqTuyVRMfLJptqKAcozptLJkfVUEbMFOwLKOcqTSfVTkyqUEypaZtLJ5xVT51oJWypaZfVTyhVT9lMTIlYPOzpz9gVUEbnKZtoJImp2SaMFjtnJqho3WcozptqTuyVTAupTy0LJjtoTI0qTIlplOiL2A1paWcozptnJ4tqTuyVTMcpaA0VUqipzEmVTS0VUEbMFOvMJqcoz5cozptG2LtMKMypaxtp2IhqTIhL2HhVRSfp28tnJqho3WyVTSfGPOmpTIwnJSfVTAbLKWuL3EypaZhVSqlLKNtqTuyVUA0pzyhMlOiLaEunJ5yMPO3nKEbnJ4tF3IloUxtLaWuL2ImVTShMPOupUOyozDtqTuyVUqipzDt4bPLMzkuM+XNzFOuqPO0nTHtLzIanJ5hnJ5aYvOOoTjtL2uupzSwqTIlplOcovO0nTHtMzkuMlOmnT91oTDtLzHtnJ4toT93MKVtL2SmMF4X


Solution
--------

- Rot13 encryption of a base64 encoded message.
- Decrypted message:

> The Greeks and Romans loved cryptography. Julius €easar, the famous ®oman emperor, is said to have used substitution ciphers to Encrypt his communications during war. The Çeasar cipher gets its name from this famous ruler. Julius ©easar use AlphabeTs with a shift of 3 to encrypt his messages. His great nephew and successor, @ugustus, used a right shift of 1 to encrypt his messages. The cipher used by ∆ugustus did not Wrap Around to the beginning of the alphabet. If you could decrypt this message, you obviously know, that the cipher used to encrypt it used a Rot13 algorithm, a variant of the ¢easar cipher with Shift 13.
Construct the Flag using all the capital letters and numbers, in order, from this message, ignoring the capital letters occurring in the first words at the beginning Of every sentence. Also ignore alL special characters. Wrap the string obtained within Kurly braces and append the word ‘flag’ at the beginning. All characters in the flag should be in lower case.

- flag{great31war13s13folk}
