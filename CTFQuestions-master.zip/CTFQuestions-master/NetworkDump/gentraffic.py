REQ = "for i in {1..2000}; do `curl -s -X POST http://listentothis.com:8080/listentothis/login --data 'email=infosec@walmart.com&password=%s&_csrf=%s'`; done"

lst = []

with open("flag.txt", "r") as f:
	for line in f:
		lst.append(line.strip())


import os
import uuid
import time

for f in lst:
	u = str(uuid.uuid1())
	os.system(REQ%(f, u))
	time.sleep(0.1)



"""

Solution:

tshark -r dump.pcap -2 -R "http.user_agent contains "Mozilla" and http.request.full_uri contains login" -T fields -e tcp.stream
390
392
1501
2650
2652

tshark -nr dump.pcap -q -z follow,tcp,ascii,1501 | grep flag

"""