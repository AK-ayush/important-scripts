#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/ptrace.h>
struct security 
{
    int priority;
    char *name;
};

void print_flag()
{
    if (ptrace(PTRACE_TRACEME, 0, NULL, 0) == -1){
  	printf("Please dont use debuggers!\n");
	return ;
    }
    printf("\x68\x33\x34\x70\x30\x76\x33");
    printf("\x72\x2f\x3d");printf("\x7c\x5f\x30\x76\x76");
}

int main(int argc, char **argv)
{
    struct security *i1, *i2;
    
    i1 = malloc(sizeof(struct security));
    i1->priority = 1;
    i1->name = (char *) malloc(8);

    i2 = malloc(sizeof(struct security));
    i2->priority = 2;
    i2->name = (char *)malloc(8);

    strcpy(i1->name, argv[1]);
    strcpy(i2->name, argv[2]);

    printf("and that's a wrap folks!\n");
}

