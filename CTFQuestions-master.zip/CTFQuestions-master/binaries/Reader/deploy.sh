docker build -t reader_ctf .
docker rm -f reader_serve 
docker run -d --name reader_serve -p 9090:9090 reader_ctf
