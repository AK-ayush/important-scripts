#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <sys/ptrace.h>

void print_flag()
{
 if (ptrace(PTRACE_TRACEME, 0, NULL, 0) == -1)
  return;
 printf("\\x53\\x55\\x68\\x68\\x64\\x6d");
 printf("\\x56\\x50\\x64\\x6d\\x56\\x79");
 printf("\\x5a\\x6d\\x78\\x76\\x64\\x32");
 printf("\\x35\\x55\\x61\\x47\\x56\\x54");
 printf("\\x64\\x47\\x46\\x6a\\x61\\x77\\x3d\\x3d");
}

int main(int argc, char **argv)
{
 volatile int (*fp)();
 char buffer[64];

 fp = 0;

 gets(buffer);

 if(fp) {
  printf("calling function pointer, jumping to 0x%08x\n", fp);
  fp();
 }
}
