<html>
<head>
	<style>
		body, pre {
 				color: #7b7b7b;
			font: 300 16px/25px "Roboto",Helvetica,Arial,sans-serif;
		}
	</style>
<meta name="generator" content="vi2html">
</head>
<body>
	<form action="/action.php" method="post">
		<p>username: <input type="text" name="username" id="username"/></p>
		<p>password: <input type="password" name="password" id="password"/></p>
		<p><input type="submit" /></p>
	</form>
</body>
</html>
