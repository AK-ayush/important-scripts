<html>
<title> Admin Page </title>
<body>
<?php
$username = "";
$password = "";

if (isset($_POST["password"]) && isset($_POST["username"])) {
  $password = $_POST["password"];
  $username = $_POST["username"];
} else {
  echo "No details provided !!";
  var_dump($_POST);
}

  if (strcmp($username, "admin") == 0 && strcmp($password, "flag{kr3am_t@p3d_up_h3ar1_ft_clar@_ma3}") == 0) {
    echo "<p>" .
      "Welcome admin<br/>" .
      "Enjoy: <a href='https://www.youtube.com/watch?v=unZNdxmqvwU'>KREAM - Taped Up Heart Ft. Clera Mae</a><br/>";
  } else {
    echo "<p>" .
      "Incorrect password !!!" .
    "</p>";
  }
?>
</body>
</html>
