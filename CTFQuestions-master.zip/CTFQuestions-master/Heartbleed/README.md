# heartbleed

Docker container with vulnerable version of openssl (see cve-2014-0160).

### Environment Setup :

#### Requires :
* Network: 
    - `docker network create --subnet 172.16.2.0/24 heartbleed`
        - `docker build -t heartbleed:latest -f Dockerfile .`
            - `docker build -t heartbleed_client:latest -f client/Dockerfile client/`

#### Containers
            1. `docker run -it -d --name hb --net heartbleed --ip 172.16.2.2 -p 8443:443 -v $(pwd)/site:/var/www heartbleed:latest`
            2. `docker run -it -d --name client --net heartbleed --ip 172.16.2.10 heartbleed_client:latest`
