#!/bin/bash
while :
do
	curl -k -X POST https://172.16.2.2:443/action.php --data 'username=admin&password=flag{kr3am_t@p3d_up_h3ar1_ft_clar@_ma3}' -o /dev/null -s 2>&1
	sleep 300
done
