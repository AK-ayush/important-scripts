import subprocess
import os
import sys
from random import randint
from sets import Set

def runCmd(cmds):
    p = subprocess.Popen(cmds, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    output, err = p.communicate()
    return output, err


FLAG = "flag{n0t_as_g0od_as_middl3_Ou1_righ1}"
ITERATIONS = 2048
# Seed

with open("flag.txt", "w") as f:
	f.write(FLAG)

cmd = [
    "tar -cvf bomb{} {} && rm -f {}", # tar
    "tar -cvzf bomb{} {} && rm -f {}", # gzip
    "tar -cvjf bomb{} {} && rm -f {}", # bzip2
    "zip bomb{} {} && rm -f {}" # zip
]

ext = [
    "tar",
    "gz",
    "bz2",
    "zip",
    "txt"
]

st = Set()
runCmd("tar -cvf bomb flag.txt && rm -f flag.txt")
prev = "bomb"
pext = 4

idx = 0
while idx < ITERATIONS:
    idx += 1

    c = randint(0, 3)
    print "[*] Iteration : {}, ext: {}".format(idx, ext[c])

    g = randint(100000, 200000)

    while g in st:
        g = randint(100000, 200000)

    runCmd(cmd[c].format(g, prev, prev))
    prev = "bomb{}".format(g)
    if c == 3:
        runCmd("mv bomb{}.zip bomb{}".format(g, g))
    pext = c
