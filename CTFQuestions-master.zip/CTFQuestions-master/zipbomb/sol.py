import os
import sys
import subprocess

# Solution Credits : the mysterious and unique nms ;)

containers = {"tar" : "POSIX tar archive", "gzip" : "gzip compressed data", "zip" : "Zip archive", "bz2" : "bzip2 compressed data", "plain" : "ASCII text"}

def runCmd(cmds):
    p = subprocess.Popen(cmds, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    output, err = p.communicate()
    return output, err

print "[+] defusing the zipbomb !"
idx = 0
while True:
    filename, e = runCmd("ls bomb*")
    filename = filename.strip()

    if len(filename) == 0:
        break

    fileInfo, e = runCmd("file {}".format(filename))
    print "[*] iteration: {}, filename: {}, fileinfo : {}".format(idx, filename, fileInfo.strip())
    idx += 1

    if containers["tar"] in fileInfo or containers["gzip"] in fileInfo:
        cmd = "tar -xvf {} && rm -f {}".format(filename, filename)
        print "[*] running {}".format(cmd)
        runCmd(cmd)
    elif containers["zip"] in fileInfo:
        cmd = "unzip {} && rm -f {}".format(filename, filename)
        print "[*] running {}".format(cmd)
        runCmd(cmd)
    elif containers["bz2"] in fileInfo:
        cmd = "bzip2 -d {} && rm -f {}".format(filename, filename)
        print "[*] running {}".format(cmd)
        runCmd(cmd)
    else:
        break

print "[+] Completed the processing !"
if os.path.exists("flag.txt"):
    with open("flag.txt", "r") as f:
        print "[+] Flag: {}".format(f.read())
else:
    print "[-] Flag file not found, something went wrong"
